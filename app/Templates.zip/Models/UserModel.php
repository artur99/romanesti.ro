<?php

namespace Models;

use Stringy\Stringy as S;
// use Hybrid_Auth;
use Hybrid_Auth;
use PDO;

class UserModel extends BaseModel{
    protected $hybridauth;

    function in(){
        $has = $this->session->has('user');
        if(!$has){
            return false;
        }
        $user = $this->session->get('user');
        if(!$user){
            return false;
        }
        return true;
    }
    function info(){
        if($this->in())
            return $this->session->get('user');
        return false;
    }

    function login($lng_l, $lng_r, $lat_l, $lat_r){
        $stmt = $this->db->prepare("SELECT * FROM magazine_fizice WHERE coord_lat > :lat_l AND coord_lat < :lat_r AND coord_lng > :lng_l AND coord_lng < :lng_r ORDER BY romanesc DESC LIMIT 100");
        $stmt->bindValue('lng_l', $lng_l);
        $stmt->bindValue('lng_r', $lng_r);
        $stmt->bindValue('lat_l', $lat_l);
        $stmt->bindValue('lat_r', $lat_r);
        $stmt->execute();
        $result = $stmt->fetchAll();

        return $result;
    }
}
