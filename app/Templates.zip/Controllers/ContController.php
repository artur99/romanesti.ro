<?php

namespace Controllers;

use Silex\Application;
use Silex\Api\ControllerProviderInterface;

use Models\UserModel;

class ContController implements ControllerProviderInterface{
    public function connect(Application $app){
        $indexController = $app['controllers_factory'];
        $indexController->get('/', [$this, 'index']);
        $indexController->get('/fblogin', [$this, 'fblogin']);

        $this->userModel = new UserModel($app['db'], $app['session']);
        $app['twig']->addGlobal('user_in', $this->userModel->in());
        $app['twig']->addGlobal('user', $this->userModel->info());

        return $indexController;
    }
    public function index(Application $app){
        $lnk = $this->userModel->init();
        if($lnk !== true){
            return $app->redirect($lnk);
        }

        $twigdata = [
            // 'date' => $themodel->getdate()
        ];
        return $app['twig']->render('cont_out.twig', $twigdata);
    }
    public function fblogin(Application $app){
        $this->userModel->init();
        return $app->redirect('/cont');
    }
}
