<?php
namespace Misc;

class MailClass{
    function __construct(){
        //Nothing here...
    }
    public function send_signup($email){

    }

}
